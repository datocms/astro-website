DatoCMS logo files

wordmark    The symbol and the name. Use this one first.
symbol      The D alone, where the wordmark does not fit.
avatar      The dark symbol on purple, for a profile picture that a circle cuts.
app-icon    The dark symbol on purple, for a square with round corners.

dark is for a light ground. white is for a dark ground.
purple is for the symbol alone, on a dark ground.
Do not put the symbol alone in a circle: use the avatar.

The rules: https://www.datocms.com/brand
